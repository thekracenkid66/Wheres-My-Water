<?xml version="1.0"?>
<InteractiveObject>
	<Shapes>
		<Shape>
			<Point pos="0 4" />
			<Point pos="2.82 2.82" />
			<Point pos="4 0" />
			<Point pos="2.82 -2.82" />
			<Point pos="0 -4" />
			<Point pos="-2.82 -2.82" />
			<Point pos="-4 0" />
			<Point pos="-2.82 2.82" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/bomb.sprite" pos="0 0" angle="0" gridSize="9.8 -9.8" />
	</Sprites>
	<DefaultProperties>
		<Property name="Type" value="bomb" />
	</DefaultProperties>
</InteractiveObject>
