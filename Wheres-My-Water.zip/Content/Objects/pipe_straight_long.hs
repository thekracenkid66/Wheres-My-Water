<?xml version="1.0"?>
<InteractiveObject>
	<!-- basic pipe section (straight) -->
	<Shapes>
		<Shape>
			<Point pos="-6 1" />
			<Point pos="6 1" />
			<Point pos="6 -1" />
			<Point pos="-6 -1" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/pipe_straight.sprite" pos="0 0" angle="0" gridSize="12 -2" />
	</Sprites>
	<DefaultProperties>
	</DefaultProperties>
</InteractiveObject>
