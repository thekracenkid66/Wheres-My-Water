<?xml version="1.0"?>
<InteractiveObject>
	<!-- basic pipe section (45 degree bend) -->
	<Shapes>
		<Shape>
			<Point pos="-1.5 1.3" />
			<Point pos="0 1.3" />
			<Point pos="1.5 0" />
			<Point pos="0.3 -1.2" />
			<Point pos="-0.5 -0.5" />
			<Point pos="-1.5 -0.5" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/pipe_bend_1.sprite" pos="0 0" angle="0" gridSize="2.9 -2.9" />
	</Sprites>
	<DefaultProperties>
	</DefaultProperties>
</InteractiveObject>
